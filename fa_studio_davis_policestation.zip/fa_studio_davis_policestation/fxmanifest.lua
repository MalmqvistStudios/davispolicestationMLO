fx_version 'cerulean'
game 'gta5'
lua54 "yes"

author 'Fastudio'
description 'PoliceStation'
version '1.0.0'

this_is_a_map 'yes'

